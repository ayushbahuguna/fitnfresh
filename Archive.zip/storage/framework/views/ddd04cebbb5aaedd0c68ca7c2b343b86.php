
<div class="card group flex flex-col">

    
    <a href="<?php echo e(route('products.show', $product->slug)); ?>" class="relative block overflow-hidden bg-brand-bg aspect-square">
        <?php if($product->primaryImage): ?>
            <img
                src="<?php echo e($product->primary_image_url); ?>"
                alt="<?php echo e($product->name); ?>"
                class="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                loading="lazy"
            >
        <?php else: ?>
            <div class="flex h-full w-full items-center justify-center">
                <svg class="h-16 w-16 text-border" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/>
                </svg>
            </div>
        <?php endif; ?>

        
        <div class="absolute left-2.5 top-2.5 flex flex-col gap-1.5">
            <?php if($product->is_featured): ?>
                <span class="badge badge-accent text-[10px]">Bestseller</span>
            <?php endif; ?>
            <?php if($product->hasDiscount()): ?>
                <span class="badge badge-primary text-[10px]"><?php echo e($product->discountPercent()); ?>% OFF</span>
            <?php endif; ?>
        </div>

        
        <?php if (! ($product->isInStock())): ?>
            <div class="absolute inset-0 bg-brand-text/40 flex items-center justify-center">
                <span class="bg-surface text-brand-text text-xs font-bold px-3 py-1.5 rounded-full">Out of Stock</span>
            </div>
        <?php endif; ?>
    </a>

    
    <div class="flex flex-1 flex-col p-3.5 sm:p-4">
        <a href="<?php echo e(route('products.show', $product->slug)); ?>" class="flex-1">
            <h3 class="font-serif text-sm font-semibold text-brand-text line-clamp-2 hover:text-primary transition-colors sm:text-base">
                <?php echo e($product->name); ?>

            </h3>
            <?php if($product->short_description): ?>
                <p class="mt-1 text-xs text-brand-text/55 line-clamp-2 leading-relaxed">
                    <?php echo e($product->short_description); ?>

                </p>
            <?php endif; ?>
        </a>

        <div class="mt-3">
            
            <div class="flex items-baseline gap-1.5 flex-wrap">
                <span class="text-base font-bold text-primary sm:text-lg">
                    ₹<?php echo e(number_format($product->price)); ?>

                </span>
                <?php if($product->hasDiscount()): ?>
                    <span class="text-xs text-brand-text/40 line-through">
                        ₹<?php echo e(number_format($product->compare_price)); ?>

                    </span>
                <?php endif; ?>
            </div>

            
            <?php if($product->isLowStock()): ?>
                <p class="mt-0.5 text-xs font-medium text-amber-600">Only <?php echo e($product->stock); ?> left!</p>
            <?php endif; ?>

            
            <button
                class="btn btn-secondary w-full mt-3 btn-sm"
                <?php echo e(! $product->isInStock() ? 'disabled' : ''); ?>

                data-product-id="<?php echo e($product->id); ?>"
                data-action="add-to-cart"
            >
                <?php if($product->isInStock()): ?>
                    <svg class="h-3.5 w-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M12 4v16m8-8H4"/>
                    </svg>
                    Add to Cart
                <?php else: ?>
                    Out of Stock
                <?php endif; ?>
            </button>
        </div>
    </div>
</div>
<?php /**PATH /Users/ayushbahuguna/Documents/Projects/fitnfresh_laravel/resources/views/components/product-card.blade.php ENDPATH**/ ?>