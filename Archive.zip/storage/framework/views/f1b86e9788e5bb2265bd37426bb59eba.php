<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" class="scroll-smooth">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    
    <title><?php echo $__env->yieldContent('title', 'Premium Health & Fitness Supplements'); ?> — FitNFresh</title>
    <meta name="description" content="<?php echo $__env->yieldContent('meta_description', 'FitNFresh offers premium, lab-tested health and fitness supplements. Pure ingredients, real results.'); ?>">

    
    <meta property="og:title" content="<?php echo $__env->yieldContent('title', 'FitNFresh'); ?> — FitNFresh">
    <meta property="og:description" content="<?php echo $__env->yieldContent('meta_description', 'Premium health & fitness supplements.'); ?>">
    <meta property="og:type" content="website">
    <meta property="og:site_name" content="FitNFresh">

    
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('favicon.ico')); ?>">

    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Playfair+Display:wght@600;700;800&display=swap" rel="stylesheet">

    
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

    
    <?php echo $__env->yieldPushContent('head'); ?>
</head>
<body class="bg-surface antialiased">

    
    <a href="#main-content"
       class="sr-only focus:not-sr-only focus:fixed focus:top-4 focus:left-4 focus:z-50 btn btn-primary btn-sm">
        Skip to content
    </a>

    
    <?php echo $__env->make('components.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    
    <?php if(session('success')): ?>
        <div class="container-brand pt-4">
            <?php echo $__env->make('components.alert', ['type' => 'success', 'message' => session('success')], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="container-brand pt-4">
            <?php echo $__env->make('components.alert', ['type' => 'error', 'message' => session('error')], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
    <?php endif; ?>

    <?php if(session('warning')): ?>
        <div class="container-brand pt-4">
            <?php echo $__env->make('components.alert', ['type' => 'warning', 'message' => session('warning')], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
    <?php endif; ?>

    
    <main id="main-content">
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    
    <?php echo $__env->make('components.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>

    
    <?php echo $__env->yieldPushContent('scripts'); ?>

</body>
</html>
<?php /**PATH /Users/ayushbahuguna/Documents/Projects/fitnfresh_laravel/resources/views/layouts/app.blade.php ENDPATH**/ ?>