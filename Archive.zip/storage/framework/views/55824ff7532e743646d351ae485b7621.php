<?php $__env->startSection('title', 'All Products'); ?>
<?php $__env->startSection('meta_description', 'Browse our full range of premium health and fitness supplements.'); ?>

<?php $__env->startSection('content'); ?>


<div class="bg-primary">
    <div class="container-brand py-10">
        <div class="flex flex-col gap-1 sm:flex-row sm:items-end sm:justify-between">
            <div>
                <p class="text-sm font-semibold uppercase tracking-widest text-accent">FitNFresh</p>
                <h1 class="font-serif text-3xl font-bold text-brand-inverse sm:text-4xl">Our Products</h1>
            </div>
            <p class="text-sm text-white/50">
                <?php echo e($products->total()); ?> <?php echo e(Str::plural('product', $products->total())); ?> found
            </p>
        </div>
    </div>
</div>

<div class="bg-brand-bg">
    <div class="container-brand py-8">

        
        <form method="GET" action="<?php echo e(route('products.index')); ?>"
              class="mb-8 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between"
              x-data>
            
            <div class="relative flex-1 max-w-sm">
                <svg class="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-brand-text/40"
                     fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
                </svg>
                <input
                    type="search"
                    name="search"
                    value="<?php echo e($filters['search'] ?? ''); ?>"
                    placeholder="Search products..."
                    class="input-field pl-9 bg-surface"
                    @keydown.enter="$el.closest('form').submit()"
                >
            </div>

            
            <div class="flex items-center gap-2 flex-wrap">
                <span class="text-sm text-brand-text/60 hidden sm:block">Sort:</span>
                <?php
                    $sorts = ['newest' => 'Newest', 'featured' => 'Featured', 'price_asc' => 'Price: Low–High', 'price_desc' => 'Price: High–Low'];
                    $currentSort = $filters['sort'] ?? 'newest';
                ?>
                <?php $__currentLoopData = $sorts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(request()->fullUrlWithQuery(['sort' => $val])); ?>"
                       class="px-3 py-1.5 rounded-full text-xs font-semibold border transition-colors
                              <?php echo e($currentSort === $val
                                  ? 'bg-primary text-brand-inverse border-primary'
                                  : 'bg-surface text-brand-text/70 border-border hover:border-primary hover:text-primary'); ?>">
                        <?php echo e($label); ?>

                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php if(! empty($filters['search']) || ! empty($filters['sort'])): ?>
                    <a href="<?php echo e(route('products.index')); ?>"
                       class="text-xs text-brand-text/50 hover:text-red-500 transition-colors ml-1">
                        Clear
                    </a>
                <?php endif; ?>
            </div>
        </form>

        
        <?php if($products->isEmpty()): ?>
            <div class="py-20 text-center">
                <svg class="mx-auto h-14 w-14 text-border mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"/>
                </svg>
                <p class="font-serif text-xl font-semibold text-brand-text">No products found</p>
                <p class="mt-1 text-sm text-brand-text/60">Try a different search or browse all products.</p>
                <a href="<?php echo e(route('products.index')); ?>" class="btn btn-primary mt-5">Browse All</a>
            </div>
        <?php else: ?>
            <div class="grid grid-cols-2 gap-4 sm:gap-5 lg:grid-cols-3 xl:grid-cols-4">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $__env->make('components.product-card', compact('product'), array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            
            <?php if($products->hasPages()): ?>
                <div class="mt-10 flex justify-center">
                    <?php echo e($products->links()); ?>

                </div>
            <?php endif; ?>
        <?php endif; ?>

    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/ayushbahuguna/Documents/Projects/fitnfresh_laravel/resources/views/pages/products/index.blade.php ENDPATH**/ ?>