<?php $__env->startSection('title', 'Products'); ?>

<?php $__env->startSection('content'); ?>

<div class="mb-6 flex items-center justify-between gap-4">
    <form method="GET" action="<?php echo e(route('admin.products.index')); ?>" class="relative w-full max-w-sm">
        <svg class="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-brand-text/40" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
            <path stroke-linecap="round" stroke-linejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
        </svg>
        <input type="search" name="search" value="<?php echo e(request('search')); ?>"
               placeholder="Search products..."
               class="input-field pl-9">
    </form>
    <a href="<?php echo e(route('admin.products.create')); ?>" class="btn btn-primary shrink-0">
        <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
            <path stroke-linecap="round" stroke-linejoin="round" d="M12 4v16m8-8H4"/>
        </svg>
        Add Product
    </a>
</div>

<div class="card overflow-hidden">
    <div class="overflow-x-auto">
        <table class="w-full text-sm">
            <thead>
                <tr class="border-b border-border bg-brand-bg text-left">
                    <th class="px-4 py-3 font-semibold text-brand-text/70">Product</th>
                    <th class="px-4 py-3 font-semibold text-brand-text/70">SKU</th>
                    <th class="px-4 py-3 font-semibold text-brand-text/70">Price</th>
                    <th class="px-4 py-3 font-semibold text-brand-text/70">Stock</th>
                    <th class="px-4 py-3 font-semibold text-brand-text/70">Status</th>
                    <th class="px-4 py-3 font-semibold text-brand-text/70">Actions</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-border">
                <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="hover:bg-brand-bg/50 transition-colors">
                        
                        <td class="px-4 py-3">
                            <div class="flex items-center gap-3">
                                <?php if($product->primaryImage): ?>
                                    <img src="<?php echo e($product->primary_image_url); ?>"
                                         alt="<?php echo e($product->name); ?>"
                                         class="h-10 w-10 rounded-lg object-cover border border-border shrink-0">
                                <?php else: ?>
                                    <div class="h-10 w-10 rounded-lg bg-brand-bg border border-border flex items-center justify-center shrink-0">
                                        <svg class="h-5 w-5 text-border" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1.5">
                                            <path stroke-linecap="round" stroke-linejoin="round" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/>
                                        </svg>
                                    </div>
                                <?php endif; ?>
                                <div>
                                    <p class="font-semibold text-brand-text line-clamp-1"><?php echo e($product->name); ?></p>
                                    <p class="text-xs text-brand-text/50"><?php echo e($product->category?->name); ?></p>
                                </div>
                            </div>
                        </td>
                        <td class="px-4 py-3 font-mono text-xs text-brand-text/70"><?php echo e($product->sku); ?></td>
                        <td class="px-4 py-3 font-semibold text-brand-text">₹<?php echo e(number_format($product->price)); ?></td>
                        <td class="px-4 py-3">
                            <?php if($product->stock === 0): ?>
                                <span class="text-red-600 font-semibold">0 — OOS</span>
                            <?php elseif($product->stock <= 10): ?>
                                <span class="text-amber-600 font-semibold"><?php echo e($product->stock); ?> — Low</span>
                            <?php else: ?>
                                <span class="text-brand-text"><?php echo e($product->stock); ?></span>
                            <?php endif; ?>
                        </td>
                        <td class="px-4 py-3">
                            <?php if($product->is_active): ?>
                                <span class="badge badge-primary">Active</span>
                            <?php else: ?>
                                <span class="badge bg-red-100 text-red-700">Inactive</span>
                            <?php endif; ?>
                            <?php if($product->is_featured): ?>
                                <span class="badge badge-accent ml-1">Featured</span>
                            <?php endif; ?>
                        </td>
                        <td class="px-4 py-3">
                            <div class="flex items-center gap-2">
                                <a href="<?php echo e(route('products.show', $product->slug)); ?>"
                                   target="_blank"
                                   class="text-brand-text/50 hover:text-primary transition-colors"
                                   title="Preview">
                                    <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                                        <path stroke-linecap="round" stroke-linejoin="round" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"/>
                                    </svg>
                                </a>
                                <a href="<?php echo e(route('admin.products.edit', $product->id)); ?>"
                                   class="text-brand-text/50 hover:text-primary transition-colors"
                                   title="Edit">
                                    <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                                        <path stroke-linecap="round" stroke-linejoin="round" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/>
                                    </svg>
                                </a>
                                <form method="POST" action="<?php echo e(route('admin.products.destroy', $product->id)); ?>"
                                      x-data
                                      @submit.prevent="if(confirm('Delete <?php echo e(addslashes($product->name)); ?>? This cannot be undone.')) $el.submit()">
                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="text-brand-text/50 hover:text-red-600 transition-colors" title="Delete">
                                        <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                                            <path stroke-linecap="round" stroke-linejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/>
                                        </svg>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" class="px-4 py-16 text-center text-brand-text/50">
                            No products yet.
                            <a href="<?php echo e(route('admin.products.create')); ?>" class="text-primary hover:underline font-medium ml-1">Add your first product</a>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <?php if($products->hasPages()): ?>
        <div class="border-t border-border px-4 py-3">
            <?php echo e($products->links()); ?>

        </div>
    <?php endif; ?>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/ayushbahuguna/Documents/Projects/fitnfresh_laravel/resources/views/pages/admin/products/index.blade.php ENDPATH**/ ?>