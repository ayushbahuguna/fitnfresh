<footer class="bg-primary text-brand-inverse">

    
    <div class="container-brand py-12 lg:py-16">
        <div class="grid grid-cols-1 gap-10 md:grid-cols-2 lg:grid-cols-4">

            
            <div class="lg:col-span-1">
                <a href="<?php echo e(route('home')); ?>" class="mb-4 inline-block">
                    <span class="font-serif text-2xl font-bold text-brand-inverse">FitNFresh</span>
                </a>
                <p class="mt-3 text-sm leading-relaxed text-white/60 max-w-xs">
                    Premium health & fitness supplements crafted for real results.
                    Pure ingredients, transparent sourcing, and science-backed formulations.
                </p>

                
                <div class="mt-6 flex items-center gap-3">
                    
                    <a href="#" aria-label="Instagram"
                       class="flex h-9 w-9 items-center justify-center rounded-full border border-white/20 text-white/60 transition-colors hover:border-accent hover:text-accent">
                        <svg class="h-4 w-4" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
                        </svg>
                    </a>
                    
                    <a href="#" aria-label="Facebook"
                       class="flex h-9 w-9 items-center justify-center rounded-full border border-white/20 text-white/60 transition-colors hover:border-accent hover:text-accent">
                        <svg class="h-4 w-4" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                        </svg>
                    </a>
                    
                    <a href="#" aria-label="YouTube"
                       class="flex h-9 w-9 items-center justify-center rounded-full border border-white/20 text-white/60 transition-colors hover:border-accent hover:text-accent">
                        <svg class="h-4 w-4" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/>
                        </svg>
                    </a>
                </div>
            </div>

            
            <div>
                <h3 class="mb-4 text-sm font-semibold uppercase tracking-widest text-accent">
                    Shop
                </h3>
                <ul class="space-y-2.5">
                    <li>
                        <a href="<?php echo e(route('products.index')); ?>"
                           class="text-sm text-white/60 transition-colors hover:text-white">
                            All Products
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('products.index')); ?>?featured=1"
                           class="text-sm text-white/60 transition-colors hover:text-white">
                            Best Sellers
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('products.index')); ?>?new=1"
                           class="text-sm text-white/60 transition-colors hover:text-white">
                            New Arrivals
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('cart.index')); ?>"
                           class="text-sm text-white/60 transition-colors hover:text-white">
                            My Cart
                        </a>
                    </li>
                </ul>
            </div>

            
            <div>
                <h3 class="mb-4 text-sm font-semibold uppercase tracking-widest text-accent">
                    Account
                </h3>
                <ul class="space-y-2.5">
                    <?php if(auth()->guard()->check()): ?>
                        <li>
                            <a href="<?php echo e(route('profile.index')); ?>"
                               class="text-sm text-white/60 transition-colors hover:text-white">
                                My Profile
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('orders.index')); ?>"
                               class="text-sm text-white/60 transition-colors hover:text-white">
                                My Orders
                            </a>
                        </li>
                    <?php else: ?>
                        <li>
                            <a href="<?php echo e(route('login')); ?>"
                               class="text-sm text-white/60 transition-colors hover:text-white">
                                Sign In
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('register')); ?>"
                               class="text-sm text-white/60 transition-colors hover:text-white">
                                Create Account
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>

            
            <div>
                <h3 class="mb-4 text-sm font-semibold uppercase tracking-widest text-accent">
                    Help
                </h3>
                <ul class="space-y-2.5">
                    <li>
                        <a href="#contact"
                           class="text-sm text-white/60 transition-colors hover:text-white">
                            Contact Us
                        </a>
                    </li>
                    <li>
                        <a href="#faq"
                           class="text-sm text-white/60 transition-colors hover:text-white">
                            FAQs
                        </a>
                    </li>
                    <li>
                        <a href="/privacy"
                           class="text-sm text-white/60 transition-colors hover:text-white">
                            Privacy Policy
                        </a>
                    </li>
                    <li>
                        <a href="/terms"
                           class="text-sm text-white/60 transition-colors hover:text-white">
                            Terms of Service
                        </a>
                    </li>
                    <li>
                        <a href="/refund-policy"
                           class="text-sm text-white/60 transition-colors hover:text-white">
                            Refund Policy
                        </a>
                    </li>
                </ul>
            </div>

        </div>
    </div>

    
    <div class="border-t border-white/10">
        <div class="container-brand py-5">
            <div class="flex flex-wrap items-center justify-center gap-6 lg:justify-between">
                <div class="flex flex-wrap items-center justify-center gap-6">
                    <div class="flex items-center gap-2 text-xs text-white/50">
                        <svg class="h-4 w-4 text-accent" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M2.166 4.999A11.954 11.954 0 0010 1.944 11.954 11.954 0 0017.834 5c.11.65.166 1.32.166 2.001 0 5.225-3.34 9.67-8 11.317C5.34 16.67 2 12.225 2 7c0-.682.057-1.35.166-2.001zm11.541 3.708a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"/>
                        </svg>
                        <span>100% Natural</span>
                    </div>
                    <div class="flex items-center gap-2 text-xs text-white/50">
                        <svg class="h-4 w-4 text-accent" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M6.267 3.455a3.066 3.066 0 001.745-.723 3.066 3.066 0 013.976 0 3.066 3.066 0 001.745.723 3.066 3.066 0 012.812 2.812c.051.643.304 1.254.723 1.745a3.066 3.066 0 010 3.976 3.066 3.066 0 00-.723 1.745 3.066 3.066 0 01-2.812 2.812 3.066 3.066 0 00-1.745.723 3.066 3.066 0 01-3.976 0 3.066 3.066 0 00-1.745-.723 3.066 3.066 0 01-2.812-2.812 3.066 3.066 0 00-.723-1.745 3.066 3.066 0 010-3.976 3.066 3.066 0 00.723-1.745 3.066 3.066 0 012.812-2.812zm7.44 5.252a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"/>
                        </svg>
                        <span>Lab Tested</span>
                    </div>
                    <div class="flex items-center gap-2 text-xs text-white/50">
                        <svg class="h-4 w-4 text-accent" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"/>
                        </svg>
                        <span>Free Delivery ₹999+</span>
                    </div>
                    <div class="flex items-center gap-2 text-xs text-white/50">
                        <svg class="h-4 w-4 text-accent" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/>
                        </svg>
                        <span>7-Day Returns</span>
                    </div>
                </div>

                <p class="text-xs text-white/40">
                    © <?php echo e(now()->year); ?> FitNFresh. All rights reserved.
                </p>
            </div>
        </div>
    </div>

</footer>
<?php /**PATH /Users/ayushbahuguna/Documents/Projects/fitnfresh_laravel/resources/views/components/footer.blade.php ENDPATH**/ ?>