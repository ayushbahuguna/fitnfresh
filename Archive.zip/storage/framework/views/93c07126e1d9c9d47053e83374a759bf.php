<?php $__env->startSection('title', 'Sign In'); ?>

<?php $__env->startSection('content'); ?>

<section class="min-h-[calc(100vh-4rem)] bg-brand-bg flex items-center justify-center py-12 px-4">
    <div class="w-full max-w-md">

        
        <div class="card p-8 sm:p-10">

            
            <div class="mb-8 text-center">
                <a href="<?php echo e(route('home')); ?>" class="inline-block mb-4">
                    <span class="font-serif text-2xl font-bold text-primary">FitNFresh</span>
                </a>
                <h1 class="font-serif text-2xl font-bold text-brand-text">Welcome back</h1>
                <p class="mt-1.5 text-sm text-brand-text/60">
                    Sign in to your account to continue
                </p>
            </div>

            
            <?php if($errors->any()): ?>
                <div class="mb-6">
                    <?php echo $__env->make('components.alert', [
                        'type'    => 'error',
                        'message' => $errors->first(),
                    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>
            <?php endif; ?>

            
            <form method="POST" action="<?php echo e(route('login')); ?>" novalidate>
                <?php echo csrf_field(); ?>

                
                <div class="mb-4">
                    <label for="email" class="input-label">
                        Email Address <span class="text-red-500">*</span>
                    </label>
                    <input
                        type="email"
                        id="email"
                        name="email"
                        value="<?php echo e(old('email')); ?>"
                        autocomplete="email"
                        placeholder="you@example.com"
                        required
                        autofocus
                        class="input-field <?php echo e($errors->has('email') ? 'border-red-400 focus:border-red-500 focus:ring-red-100' : ''); ?>"
                    >
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="input-error"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                <div class="mb-4" x-data="{ show: false }">
                    <div class="flex items-center justify-between mb-1.5">
                        <label for="password" class="input-label mb-0">
                            Password <span class="text-red-500">*</span>
                        </label>
                        <a href="<?php echo e(route('password.request')); ?>"
                           class="text-xs text-primary hover:text-primary-light transition-colors font-medium">
                            Forgot password?
                        </a>
                    </div>
                    <div class="relative">
                        <input
                            :type="show ? 'text' : 'password'"
                            id="password"
                            name="password"
                            autocomplete="current-password"
                            placeholder="Enter your password"
                            required
                            class="input-field pr-11 <?php echo e($errors->has('password') ? 'border-red-400' : ''); ?>"
                        >
                        <button
                            type="button"
                            @click="show = !show"
                            class="absolute right-3 top-1/2 -translate-y-1/2 text-brand-text/40 hover:text-brand-text/70 transition-colors"
                            :aria-label="show ? 'Hide password' : 'Show password'"
                        >
                            <svg x-show="!show" class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1.75">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/>
                                <path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
                            </svg>
                            <svg x-show="show" x-cloak class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1.75">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l3.59 3.59m0 0A9.953 9.953 0 0112 5c4.478 0 8.268 2.943 9.543 7a10.025 10.025 0 01-4.132 5.411m0 0L21 21"/>
                            </svg>
                        </button>
                    </div>
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="input-error"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                <div class="mb-6 flex items-center gap-2.5">
                    <input
                        type="checkbox"
                        id="remember"
                        name="remember"
                        value="1"
                        class="h-4 w-4 rounded border-border text-primary accent-primary cursor-pointer"
                    >
                    <label for="remember" class="text-sm text-brand-text/70 cursor-pointer select-none">
                        Keep me signed in for 30 days
                    </label>
                </div>

                
                <button type="submit" class="btn btn-primary w-full btn-lg">
                    Sign In
                    <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M17 8l4 4m0 0l-4 4m4-4H3"/>
                    </svg>
                </button>
            </form>

            
            <div class="my-6 flex items-center gap-3">
                <div class="flex-1 border-t border-border"></div>
                <span class="text-xs text-brand-text/40 font-medium uppercase tracking-wider">New to FitNFresh?</span>
                <div class="flex-1 border-t border-border"></div>
            </div>

            
            <a href="<?php echo e(route('register')); ?>" class="btn btn-outline w-full btn-lg">
                Create an Account
            </a>

        </div>

        
        <p class="mt-5 text-center text-xs text-brand-text/40">
            <svg class="inline h-3.5 w-3.5 mr-1 mb-0.5" fill="currentColor" viewBox="0 0 20 20">
                <path fill-rule="evenodd" d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z"/>
            </svg>
            Secured with 256-bit encryption. Your data is safe.
        </p>

    </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/ayushbahuguna/Documents/Projects/fitnfresh_laravel/resources/views/pages/auth/login.blade.php ENDPATH**/ ?>