
<nav aria-label="Breadcrumb" class="mb-6">
    <ol class="flex flex-wrap items-center gap-1.5 text-sm">
        <?php $__currentLoopData = $items ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="flex items-center gap-1.5">
                <?php if($index > 0): ?>
                    <svg class="h-3.5 w-3.5 text-brand-text/30" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7"/>
                    </svg>
                <?php endif; ?>

                <?php if(isset($item['url'])): ?>
                    <a href="<?php echo e($item['url']); ?>" class="text-brand-text/50 transition-colors hover:text-primary">
                        <?php echo e($item['label']); ?>

                    </a>
                <?php else: ?>
                    <span class="font-medium text-brand-text"><?php echo e($item['label']); ?></span>
                <?php endif; ?>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ol>
</nav>
<?php /**PATH /Users/ayushbahuguna/Documents/Projects/fitnfresh_laravel/resources/views/components/breadcrumb.blade.php ENDPATH**/ ?>