<?php $__env->startSection('title', 'Premium Health & Fitness Supplements'); ?>

<?php $__env->startSection('content'); ?>

    
    <section class="relative bg-primary overflow-hidden">
        <div class="container-brand section">
            <div class="grid grid-cols-1 items-center gap-10 lg:grid-cols-2">

                
                <div class="text-center lg:text-left">
                    <span class="badge badge-accent mb-4 inline-flex">
                        100% Natural · Lab Tested
                    </span>
                    <h1 class="font-serif text-4xl font-bold text-brand-inverse leading-tight sm:text-5xl lg:text-6xl">
                        Fuel Your <span class="text-accent">Best</span><br>Performance
                    </h1>
                    <p class="mt-5 text-base text-white/70 max-w-md mx-auto lg:mx-0 lg:text-lg">
                        Premium health & fitness supplements crafted with pure ingredients
                        and science-backed formulations — because you deserve the best.
                    </p>

                    
                    <div class="mt-6 flex flex-wrap items-center justify-center gap-4 lg:justify-start">
                        <div class="flex items-center gap-1.5 text-sm text-white/60">
                            <svg class="h-4 w-4 text-accent shrink-0" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd" d="M2.166 4.999A11.954 11.954 0 0010 1.944 11.954 11.954 0 0017.834 5c.11.65.166 1.32.166 2.001 0 5.225-3.34 9.67-8 11.317C5.34 16.67 2 12.225 2 7c0-.682.057-1.35.166-2.001zm11.541 3.708a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"/>
                            </svg>
                            No Fillers
                        </div>
                        <div class="flex items-center gap-1.5 text-sm text-white/60">
                            <svg class="h-4 w-4 text-accent shrink-0" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd" d="M2.166 4.999A11.954 11.954 0 0010 1.944 11.954 11.954 0 0017.834 5c.11.65.166 1.32.166 2.001 0 5.225-3.34 9.67-8 11.317C5.34 16.67 2 12.225 2 7c0-.682.057-1.35.166-2.001zm11.541 3.708a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"/>
                            </svg>
                            GMP Certified
                        </div>
                        <div class="flex items-center gap-1.5 text-sm text-white/60">
                            <svg class="h-4 w-4 text-accent shrink-0" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd" d="M2.166 4.999A11.954 11.954 0 0010 1.944 11.954 11.954 0 0017.834 5c.11.65.166 1.32.166 2.001 0 5.225-3.34 9.67-8 11.317C5.34 16.67 2 12.225 2 7c0-.682.057-1.35.166-2.001zm11.541 3.708a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"/>
                            </svg>
                            Free Delivery ₹999+
                        </div>
                    </div>

                    
                    <div class="mt-8 flex flex-wrap items-center justify-center gap-3 lg:justify-start">
                        <a href="<?php echo e(route('products.index')); ?>" class="btn btn-primary btn-lg">
                            Shop Now
                            <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M17 8l4 4m0 0l-4 4m4-4H3"/>
                            </svg>
                        </a>
                        <a href="#how-it-works" class="btn btn-outline-accent btn-lg">
                            How It Works
                        </a>
                    </div>
                </div>

                
                <div class="flex items-center justify-center">
                    <div class="relative h-72 w-72 sm:h-96 sm:w-96 rounded-full bg-primary-light/50 flex items-center justify-center">
                        <div class="h-56 w-56 sm:h-72 sm:w-72 rounded-full bg-primary-light/60 flex items-center justify-center">
                            <div class="h-40 w-40 sm:h-52 sm:w-52 rounded-full bg-accent/10 border-2 border-accent/30 flex flex-col items-center justify-center text-center p-4">
                                <span class="font-serif text-3xl font-bold text-accent">FNF</span>
                                <span class="text-xs text-white/60 mt-1">Product Visual</span>
                                <span class="text-xs text-white/40">Phase 9</span>
                            </div>
                        </div>

                        
                        <div class="absolute top-6 right-0 bg-accent text-primary text-xs font-bold px-3 py-1.5 rounded-full shadow-lg">
                            ⭐ 4.9/5 Rating
                        </div>
                        <div class="absolute bottom-10 left-0 bg-surface text-brand-text text-xs font-semibold px-3 py-1.5 rounded-full shadow-lg">
                            10,000+ Happy Customers
                        </div>
                    </div>
                </div>
            </div>
        </div>

        
        <div class="absolute bottom-0 left-0 right-0 h-12 bg-surface-alt" style="clip-path: ellipse(55% 100% at 50% 100%)"></div>
    </section>

    
    <section class="bg-surface-alt section" id="about">
        <div class="container-brand">
            <div class="text-center mb-12">
                <span class="badge badge-primary mb-3">Why FitNFresh</span>
                <h2 class="font-serif text-3xl font-bold text-brand-text sm:text-4xl">
                    Built Different. Built Better.
                </h2>
                <p class="mt-3 text-brand-text/60 max-w-xl mx-auto">
                    We don't cut corners. Every product is third-party tested, transparently labeled,
                    and formulated for real-world results.
                </p>
            </div>

            <div class="grid grid-cols-1 gap-6 sm:grid-cols-3">
                <?php
                    $features = [
                        ['icon' => 'M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z', 'title' => 'Purity Guaranteed', 'desc' => 'Every batch is third-party lab tested for potency and safety. No hidden ingredients, ever.'],
                        ['icon' => 'M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z', 'title' => 'Science-Backed', 'desc' => 'Formulated by nutritionists and fitness experts. Dosages that actually work — not underdosed fillers.'],
                        ['icon' => 'M13 10V3L4 14h7v7l9-11h-7z', 'title' => 'Real Results', 'desc' => 'Thousands of customers have transformed their performance. Your results are our proof.'],
                    ];
                ?>

                <?php $__currentLoopData = $features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card p-6 text-center">
                        <div class="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-primary/10">
                            <svg class="h-7 w-7 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1.75">
                                <path stroke-linecap="round" stroke-linejoin="round" d="<?php echo e($feature['icon']); ?>"/>
                            </svg>
                        </div>
                        <h3 class="font-serif text-lg font-semibold text-brand-text"><?php echo e($feature['title']); ?></h3>
                        <p class="mt-2 text-sm text-brand-text/60 leading-relaxed"><?php echo e($feature['desc']); ?></p>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>

    
    <section class="section bg-surface">
        <div class="container-brand">
            <div class="flex items-end justify-between mb-8">
                <div>
                    <span class="badge badge-accent mb-2">Our Products</span>
                    <h2 class="font-serif text-3xl font-bold text-brand-text sm:text-4xl">
                        Best Sellers
                    </h2>
                </div>
                <a href="<?php echo e(route('products.index')); ?>" class="btn btn-outline btn-sm hidden sm:inline-flex">
                    View All
                    <svg class="h-3.5 w-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M17 8l4 4m0 0l-4 4m4-4H3"/>
                    </svg>
                </a>
            </div>

            <?php if($featuredProducts->isEmpty()): ?>
                <p class="text-center text-brand-text/50 py-10">Products coming soon. Check back shortly!</p>
            <?php else: ?>
                <div class="grid grid-cols-2 gap-4 sm:gap-5 lg:grid-cols-4">
                    <?php $__currentLoopData = $featuredProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo $__env->make('components.product-card', compact('product'), array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>

            <div class="mt-8 text-center sm:hidden">
                <a href="<?php echo e(route('products.index')); ?>" class="btn btn-outline">View All Products</a>
            </div>
        </div>
    </section>

    
    <section class="section bg-surface-alt" id="how-it-works">
        <div class="container-brand">
            <div class="text-center mb-12">
                <span class="badge badge-primary mb-3">Simple Process</span>
                <h2 class="font-serif text-3xl font-bold text-brand-text sm:text-4xl">
                    How It Works
                </h2>
            </div>

            <div class="grid grid-cols-1 gap-8 sm:grid-cols-3">
                <?php
                    $steps = [
                        ['number' => '01', 'title' => 'Choose Your Goal', 'desc' => 'Browse our curated range and pick the supplement that matches your fitness objective.'],
                        ['number' => '02', 'title' => 'Order Securely', 'desc' => 'Checkout with Razorpay — encrypted, fast, and hassle-free. Delivered to your door.'],
                        ['number' => '03', 'title' => 'Achieve Results', 'desc' => 'Follow the recommended usage and track your transformation week by week.'],
                    ];
                ?>

                <?php $__currentLoopData = $steps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $step): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="relative text-center">
                        <div class="mx-auto mb-5 flex h-16 w-16 items-center justify-center rounded-full bg-primary">
                            <span class="font-serif text-xl font-bold text-accent"><?php echo e($step['number']); ?></span>
                        </div>
                        <h3 class="font-serif text-lg font-semibold text-brand-text"><?php echo e($step['title']); ?></h3>
                        <p class="mt-2 text-sm text-brand-text/60 leading-relaxed max-w-xs mx-auto"><?php echo e($step['desc']); ?></p>

                        
                        <?php if(! $loop->last): ?>
                            <div class="absolute top-8 left-1/2 hidden h-0.5 w-full -translate-y-1/2 bg-border sm:block" style="left: calc(50% + 2rem); width: calc(100% - 4rem);"></div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>

    
    <section class="bg-accent">
        <div class="container-brand py-10 text-center">
            <p class="text-sm font-semibold uppercase tracking-widest text-primary mb-1">Limited Time Offer</p>
            <h2 class="font-serif text-2xl font-bold text-primary sm:text-3xl">
                Get 15% Off Your First Order
            </h2>
            <p class="mt-2 text-sm text-primary/70">Use code <strong class="font-mono">WELCOME15</strong> at checkout</p>
            <a href="<?php echo e(route('products.index')); ?>" class="btn btn-secondary mt-6 btn-lg">
                Shop Now
            </a>
        </div>
    </section>

    
    <section class="section bg-surface" id="faq">
        <div class="container-brand max-w-3xl">
            <div class="text-center mb-10">
                <span class="badge badge-primary mb-3">FAQ</span>
                <h2 class="font-serif text-3xl font-bold text-brand-text sm:text-4xl">
                    Common Questions
                </h2>
            </div>

            <div class="space-y-3" x-data="{ open: null }">
                <?php
                    $faqs = [
                        ['q' => 'Are your products safe and tested?', 'a' => 'Yes. Every FitNFresh product is third-party lab tested for purity and potency. We share certificates of analysis on each product page.'],
                        ['q' => 'How long does delivery take?', 'a' => 'Standard delivery takes 3–5 business days. Express delivery is available at checkout. Orders above ₹999 qualify for free standard shipping.'],
                        ['q' => 'What is your return policy?', 'a' => 'We offer a 7-day hassle-free return policy. If you are not satisfied with your purchase, contact us within 7 days of delivery.'],
                        ['q' => 'Are these products suitable for beginners?', 'a' => 'Yes! Our products are formulated for all fitness levels. Each product page includes clear usage guidelines and recommended dosages.'],
                        ['q' => 'Do you offer COD (Cash on Delivery)?', 'a' => 'Currently we accept online payments via Razorpay — UPI, cards, net banking, and wallets. COD is not available at this time.'],
                    ];
                ?>

                <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card overflow-visible" x-data>
                        <button
                            @click="$parent.open === <?php echo e($index); ?> ? $parent.open = null : $parent.open = <?php echo e($index); ?>"
                            class="flex w-full items-center justify-between px-5 py-4 text-left"
                        >
                            <span class="font-medium text-brand-text text-sm sm:text-base"><?php echo e($faq['q']); ?></span>
                            <svg
                                class="h-5 w-5 shrink-0 text-primary transition-transform ml-4"
                                :class="$parent.open === <?php echo e($index); ?> ? 'rotate-180' : ''"
                                fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7"/>
                            </svg>
                        </button>
                        <div
                            x-show="$parent.open === <?php echo e($index); ?>"
                            x-cloak
                            x-transition:enter="transition ease-out duration-150"
                            x-transition:enter-start="opacity-0 -translate-y-1"
                            x-transition:enter-end="opacity-100 translate-y-0"
                            class="border-t border-border px-5 py-4"
                        >
                            <p class="text-sm text-brand-text/70 leading-relaxed"><?php echo e($faq['a']); ?></p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/ayushbahuguna/Documents/Projects/fitnfresh_laravel/resources/views/pages/home/index.blade.php ENDPATH**/ ?>