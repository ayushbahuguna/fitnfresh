<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}" class="scroll-smooth">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    {{-- SEO --}}
    <title>@yield('title', 'Premium Health & Fitness Supplements') — FitNFresh</title>
    <meta name="description" content="@yield('meta_description', 'FitNFresh offers premium, lab-tested health and fitness supplements. Pure ingredients, real results.')">

    {{-- Open Graph --}}
    <meta property="og:title" content="@yield('title', 'FitNFresh') — FitNFresh">
    <meta property="og:description" content="@yield('meta_description', 'Premium health & fitness supplements.')">
    <meta property="og:type" content="website">
    <meta property="og:site_name" content="FitNFresh">

    {{-- Favicon --}}
    <link rel="icon" type="image/x-icon" href="{{ asset('favicon.ico') }}">

    {{-- Google Fonts --}}
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Playfair+Display:wght@600;700;800&display=swap" rel="stylesheet">

    {{-- Vite Assets --}}
    @vite(['resources/css/app.css', 'resources/js/app.js'])

    {{-- Page-specific head content --}}
    @stack('head')
</head>
<body class="bg-surface antialiased">

    {{-- Skip to main content (accessibility) --}}
    <a href="#main-content"
       class="sr-only focus:not-sr-only focus:fixed focus:top-4 focus:left-4 focus:z-50 btn btn-primary btn-sm">
        Skip to content
    </a>

    {{-- Navigation --}}
    @include('components.navbar')

    {{-- Flash Messages --}}
    @if (session('success'))
        <div class="container-brand pt-4">
            @include('components.alert', ['type' => 'success', 'message' => session('success')])
        </div>
    @endif

    @if (session('error'))
        <div class="container-brand pt-4">
            @include('components.alert', ['type' => 'error', 'message' => session('error')])
        </div>
    @endif

    @if (session('warning'))
        <div class="container-brand pt-4">
            @include('components.alert', ['type' => 'warning', 'message' => session('warning')])
        </div>
    @endif

    {{-- Main Content --}}
    <main id="main-content">
        @yield('content')
    </main>

    {{-- Footer --}}
    @include('components.footer')

    {{-- Alpine.js --}}
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>

    {{-- Page-specific scripts --}}
    @stack('scripts')

</body>
</html>
