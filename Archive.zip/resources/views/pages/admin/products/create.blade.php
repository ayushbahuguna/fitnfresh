@extends('layouts.admin')
@section('title', 'Add Product')

@section('content')

<div class="mb-6">
    <a href="{{ route('admin.products.index') }}" class="inline-flex items-center gap-1.5 text-sm text-brand-text/60 hover:text-primary transition-colors">
        <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
            <path stroke-linecap="round" stroke-linejoin="round" d="M10 19l-7-7m0 0l7-7m-7 7h18"/>
        </svg>
        Back to Products
    </a>
</div>

@if ($errors->any())
    <div class="mb-6">
        @include('components.alert', ['type' => 'error', 'message' => 'Please fix the errors below.'])
    </div>
@endif

<form method="POST"
      action="{{ route('admin.products.store') }}"
      enctype="multipart/form-data"
      x-data="productForm()"
>
    @csrf

    <div class="grid grid-cols-1 gap-6 lg:grid-cols-3">

        {{-- ── Main Column ── --}}
        <div class="lg:col-span-2 space-y-6">

            {{-- Basic Info --}}
            <div class="card p-5">
                <h2 class="font-serif text-base font-semibold text-brand-text mb-4">Product Information</h2>
                <div class="space-y-4">
                    <div>
                        <label class="input-label">Product Name <span class="text-red-500">*</span></label>
                        <input type="text" name="name" value="{{ old('name') }}" required class="input-field {{ $errors->has('name') ? 'border-red-400' : '' }}">
                        @error('name')<p class="input-error">{{ $message }}</p>@enderror
                    </div>
                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="input-label">Category <span class="text-red-500">*</span></label>
                            <select name="category_id" required class="input-field">
                                <option value="">Select category</option>
                                @foreach ($categories as $cat)
                                    <option value="{{ $cat->id }}" {{ old('category_id') == $cat->id ? 'selected' : '' }}>
                                        {{ $cat->name }}
                                    </option>
                                @endforeach
                            </select>
                            @error('category_id')<p class="input-error">{{ $message }}</p>@enderror
                        </div>
                        <div>
                            <label class="input-label">SKU <span class="text-red-500">*</span></label>
                            <input type="text" name="sku" value="{{ old('sku') }}" required class="input-field {{ $errors->has('sku') ? 'border-red-400' : '' }}" placeholder="FNF-001">
                            @error('sku')<p class="input-error">{{ $message }}</p>@enderror
                        </div>
                    </div>
                    <div>
                        <label class="input-label">Short Description</label>
                        <textarea name="short_description" rows="2" maxlength="500" class="input-field resize-none" placeholder="Brief summary shown in product cards...">{{ old('short_description') }}</textarea>
                        @error('short_description')<p class="input-error">{{ $message }}</p>@enderror
                    </div>
                    <div>
                        <label class="input-label">Full Description <span class="text-red-500">*</span></label>
                        <textarea name="description" rows="6" required class="input-field resize-y {{ $errors->has('description') ? 'border-red-400' : '' }}" placeholder="Detailed product description, ingredients, usage...">{{ old('description') }}</textarea>
                        @error('description')<p class="input-error">{{ $message }}</p>@enderror
                    </div>
                </div>
            </div>

            {{-- Pricing & Stock --}}
            <div class="card p-5">
                <h2 class="font-serif text-base font-semibold text-brand-text mb-4">Pricing & Stock</h2>
                <div class="grid grid-cols-3 gap-4">
                    <div>
                        <label class="input-label">Sale Price (₹) <span class="text-red-500">*</span></label>
                        <input type="number" name="price" value="{{ old('price') }}" step="0.01" min="0" required class="input-field {{ $errors->has('price') ? 'border-red-400' : '' }}" placeholder="0.00">
                        @error('price')<p class="input-error">{{ $message }}</p>@enderror
                    </div>
                    <div>
                        <label class="input-label">Compare Price (₹)</label>
                        <input type="number" name="compare_price" value="{{ old('compare_price') }}" step="0.01" min="0" class="input-field" placeholder="MRP">
                        @error('compare_price')<p class="input-error">{{ $message }}</p>@enderror
                    </div>
                    <div>
                        <label class="input-label">Stock Qty <span class="text-red-500">*</span></label>
                        <input type="number" name="stock" value="{{ old('stock', 0) }}" min="0" required class="input-field {{ $errors->has('stock') ? 'border-red-400' : '' }}">
                        @error('stock')<p class="input-error">{{ $message }}</p>@enderror
                    </div>
                </div>
            </div>

            {{-- Images --}}
            <div class="card p-5">
                <h2 class="font-serif text-base font-semibold text-brand-text mb-1">Product Images</h2>
                <p class="text-xs text-brand-text/50 mb-4">Upload up to 6 images. First image becomes the primary. JPEG, PNG, WebP. Max 2MB each.</p>
                <input type="file" name="images[]" multiple accept="image/*" class="input-field" id="imageInput">
                @error('images.*')<p class="input-error">{{ $message }}</p>@enderror
            </div>

            {{-- Variants --}}
            <div class="card p-5" x-data="{ variants: [] }">
                <div class="flex items-center justify-between mb-4">
                    <div>
                        <h2 class="font-serif text-base font-semibold text-brand-text">Variants</h2>
                        <p class="text-xs text-brand-text/50">Add size/weight options (optional)</p>
                    </div>
                    <button type="button" @click="variants.push({name:'',sku:'',price:'',stock:''})" class="btn btn-outline btn-sm">
                        + Add Variant
                    </button>
                </div>
                <template x-for="(v, i) in variants" :key="i">
                    <div class="grid grid-cols-4 gap-3 mb-3 items-start">
                        <div>
                            <label class="input-label text-xs">Name</label>
                            <input type="text" :name="'variants['+i+'][name]'" x-model="v.name" placeholder="250g" class="input-field">
                        </div>
                        <div>
                            <label class="input-label text-xs">SKU</label>
                            <input type="text" :name="'variants['+i+'][sku]'" x-model="v.sku" placeholder="FNF-001-250" class="input-field">
                        </div>
                        <div>
                            <label class="input-label text-xs">Price (₹)</label>
                            <input type="number" :name="'variants['+i+'][price]'" x-model="v.price" step="0.01" min="0" class="input-field">
                        </div>
                        <div class="flex gap-2">
                            <div class="flex-1">
                                <label class="input-label text-xs">Stock</label>
                                <input type="number" :name="'variants['+i+'][stock]'" x-model="v.stock" min="0" class="input-field">
                            </div>
                            <button type="button" @click="variants.splice(i,1)" class="mt-6 text-red-400 hover:text-red-600 shrink-0">
                                <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/>
                                </svg>
                            </button>
                        </div>
                    </div>
                </template>
                <p x-show="variants.length === 0" class="text-sm text-brand-text/40 text-center py-4">
                    No variants added — product will have a single price.
                </p>
            </div>

        </div>

        {{-- ── Sidebar Column ── --}}
        <div class="space-y-6">

            {{-- Publish --}}
            <div class="card p-5">
                <h2 class="font-serif text-base font-semibold text-brand-text mb-4">Publish</h2>
                <div class="space-y-3">
                    <label class="flex items-center gap-3 cursor-pointer">
                        <input type="hidden" name="is_active" value="0">
                        <input type="checkbox" name="is_active" value="1" {{ old('is_active', '1') ? 'checked' : '' }}
                               class="h-4 w-4 rounded border-border accent-primary">
                        <span class="text-sm font-medium text-brand-text">Active (visible to customers)</span>
                    </label>
                    <label class="flex items-center gap-3 cursor-pointer">
                        <input type="hidden" name="is_featured" value="0">
                        <input type="checkbox" name="is_featured" value="1" {{ old('is_featured') ? 'checked' : '' }}
                               class="h-4 w-4 rounded border-border accent-primary">
                        <span class="text-sm font-medium text-brand-text">Featured (homepage & bestsellers)</span>
                    </label>
                </div>
                <div class="mt-5 flex flex-col gap-2">
                    <button type="submit" class="btn btn-primary w-full">Save Product</button>
                    <a href="{{ route('admin.products.index') }}" class="btn btn-ghost w-full">Cancel</a>
                </div>
            </div>

            {{-- SEO --}}
            <div class="card p-5">
                <h2 class="font-serif text-base font-semibold text-brand-text mb-4">SEO</h2>
                <div class="space-y-3">
                    <div>
                        <label class="input-label">Meta Title</label>
                        <input type="text" name="meta_title" value="{{ old('meta_title') }}" maxlength="255" class="input-field text-sm" placeholder="Leave blank to use product name">
                    </div>
                    <div>
                        <label class="input-label">Meta Description</label>
                        <textarea name="meta_description" rows="3" maxlength="500" class="input-field text-sm resize-none" placeholder="Leave blank to use short description">{{ old('meta_description') }}</textarea>
                    </div>
                </div>
            </div>

        </div>
    </div>

</form>

@endsection
