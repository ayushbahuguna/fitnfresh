@extends('layouts.app')
@section('title', $product->meta_title ?? $product->name)
@section('meta_description', $product->meta_description ?? $product->short_description)

@section('content')

<div class="bg-brand-bg">
    <div class="container-brand py-8">

        {{-- Breadcrumb --}}
        @include('components.breadcrumb', [
            'items' => [
                ['label' => 'Home',     'url' => route('home')],
                ['label' => 'Products', 'url' => route('products.index')],
                ['label' => $product->name],
            ]
        ])

        {{-- Product Main --}}
        <div class="grid grid-cols-1 gap-8 lg:grid-cols-2 lg:gap-12" x-data="{
            selectedImage: '{{ $product->primary_image_url }}',
            selectedVariant: null,
            quantity: 1,
            @if ($product->variants->isNotEmpty())
                currentPrice: {{ $product->variants->first()->price }},
            @else
                currentPrice: {{ $product->price }},
            @endif
        }">

            {{-- ── Image Gallery ── --}}
            <div class="flex flex-col gap-3">
                {{-- Main Image --}}
                <div class="relative overflow-hidden rounded-xl bg-surface aspect-square shadow-card">
                    <img
                        :src="selectedImage"
                        alt="{{ $product->name }}"
                        class="h-full w-full object-cover"
                    >
                    @if ($product->hasDiscount())
                        <div class="absolute left-4 top-4">
                            <span class="badge badge-primary">{{ $product->discountPercent() }}% OFF</span>
                        </div>
                    @endif
                    @if ($product->is_featured)
                        <div class="absolute right-4 top-4">
                            <span class="badge badge-accent">Bestseller</span>
                        </div>
                    @endif
                </div>

                {{-- Thumbnails --}}
                @if ($product->images->count() > 1)
                    <div class="flex gap-2 overflow-x-auto pb-1">
                        @foreach ($product->images as $image)
                            <button
                                type="button"
                                @click="selectedImage = '{{ asset('storage/' . $image->image_path) }}'"
                                :class="selectedImage === '{{ asset('storage/' . $image->image_path) }}'
                                    ? 'ring-2 ring-primary ring-offset-1'
                                    : 'ring-1 ring-border hover:ring-primary/50'"
                                class="h-16 w-16 shrink-0 overflow-hidden rounded-lg transition"
                            >
                                <img
                                    src="{{ asset('storage/' . $image->image_path) }}"
                                    alt="{{ $product->name }} image {{ $loop->iteration }}"
                                    class="h-full w-full object-cover"
                                    loading="lazy"
                                >
                            </button>
                        @endforeach
                    </div>
                @endif
            </div>

            {{-- ── Product Info ── --}}
            <div class="flex flex-col">

                {{-- Category --}}
                @if ($product->category)
                    <a href="{{ route('products.index', ['category' => $product->category->slug]) }}"
                       class="text-xs font-semibold uppercase tracking-widest text-accent hover:text-accent-dark transition-colors">
                        {{ $product->category->name }}
                    </a>
                @endif

                <h1 class="font-serif text-2xl font-bold text-brand-text mt-2 sm:text-3xl">
                    {{ $product->name }}
                </h1>

                {{-- Price --}}
                <div class="mt-4 flex items-baseline gap-3">
                    <span class="text-3xl font-bold text-primary" x-text="'₹' + currentPrice.toLocaleString('en-IN')">
                        ₹{{ number_format($product->price) }}
                    </span>
                    @if ($product->hasDiscount())
                        <span class="text-lg text-brand-text/40 line-through">
                            ₹{{ number_format($product->compare_price) }}
                        </span>
                        <span class="badge badge-primary">Save ₹{{ number_format($product->compare_price - $product->price) }}</span>
                    @endif
                </div>

                {{-- Short Description --}}
                @if ($product->short_description)
                    <p class="mt-4 text-sm leading-relaxed text-brand-text/70">
                        {{ $product->short_description }}
                    </p>
                @endif

                {{-- Variants --}}
                @if ($product->variants->isNotEmpty())
                    <div class="mt-5">
                        <p class="text-sm font-semibold text-brand-text mb-2">Select Size / Weight</p>
                        <div class="flex flex-wrap gap-2">
                            @foreach ($product->variants as $variant)
                                <button
                                    type="button"
                                    @click="selectedVariant = {{ $variant->id }}; currentPrice = {{ $variant->price }}"
                                    :class="selectedVariant === {{ $variant->id }}
                                        ? 'border-primary bg-primary text-brand-inverse'
                                        : '{{ ! $variant->isInStock() ? 'opacity-40 cursor-not-allowed border-border text-brand-text/50' : 'border-border text-brand-text hover:border-primary hover:text-primary' }}'"
                                    class="relative rounded-lg border-2 px-4 py-2 text-sm font-semibold transition-all"
                                    {{ ! $variant->isInStock() ? 'disabled' : '' }}
                                >
                                    {{ $variant->name }}
                                    <span class="block text-xs font-normal opacity-80">₹{{ number_format($variant->price) }}</span>
                                    @unless ($variant->isInStock())
                                        <span class="absolute -top-1.5 -right-1.5 text-[9px] bg-red-100 text-red-600 font-bold px-1 rounded">OOS</span>
                                    @endunless
                                </button>
                            @endforeach
                        </div>
                    </div>
                @endif

                {{-- Stock Status --}}
                <div class="mt-4 flex items-center gap-2">
                    @if ($product->isInStock())
                        <span class="inline-flex h-2 w-2 rounded-full bg-green-500"></span>
                        <span class="text-sm font-medium text-green-700">
                            @if ($product->isLowStock())
                                Only {{ $product->stock }} left — order soon!
                            @else
                                In Stock
                            @endif
                        </span>
                    @else
                        <span class="inline-flex h-2 w-2 rounded-full bg-red-500"></span>
                        <span class="text-sm font-medium text-red-600">Out of Stock</span>
                    @endif
                </div>

                {{-- Quantity + Add to Cart --}}
                @if ($product->isInStock())
                    <div class="mt-6 flex items-center gap-3">
                        {{-- Quantity Stepper --}}
                        <div class="flex items-center rounded-lg border border-border bg-surface overflow-hidden">
                            <button
                                type="button"
                                @click="if(quantity > 1) quantity--"
                                class="flex h-10 w-10 items-center justify-center text-brand-text/60 hover:bg-brand-bg hover:text-brand-text transition-colors"
                            >
                                <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M20 12H4"/>
                                </svg>
                            </button>
                            <span
                                x-text="quantity"
                                class="flex h-10 w-10 items-center justify-center text-sm font-bold text-brand-text select-none border-x border-border"
                            >1</span>
                            <button
                                type="button"
                                @click="if(quantity < {{ $product->stock }}) quantity++"
                                class="flex h-10 w-10 items-center justify-center text-brand-text/60 hover:bg-brand-bg hover:text-brand-text transition-colors"
                            >
                                <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M12 4v16m8-8H4"/>
                                </svg>
                            </button>
                        </div>

                        {{-- Add to Cart (wired in Phase 4) --}}
                        <form method="POST" action="{{ route('cart.add') }}" class="flex-1">
                            @csrf
                            <input type="hidden" name="product_id" value="{{ $product->id }}">
                            <input type="hidden" name="variant_id" :value="selectedVariant">
                            <input type="hidden" name="quantity" :value="quantity">
                            <button
                                type="submit"
                                class="btn btn-primary w-full btn-lg"
                                @if ($product->variants->isNotEmpty())
                                    :disabled="!selectedVariant"
                                    :class="!selectedVariant ? 'opacity-50 cursor-not-allowed' : ''"
                                @endif
                            >
                                <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1.75">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M2.25 3h1.386c.51 0 .955.343 1.087.835l.383 1.437M7.5 14.25a3 3 0 00-3 3h15.75m-12.75-3h11.218c1.121-2.3 2.1-4.684 2.924-7.138a60.114 60.114 0 00-16.536-1.84M7.5 14.25L5.106 5.272M6 20.25a.75.75 0 11-1.5 0 .75.75 0 011.5 0zm12.75 0a.75.75 0 11-1.5 0 .75.75 0 011.5 0z"/>
                                </svg>
                                @if ($product->variants->isNotEmpty())
                                    <span x-text="selectedVariant ? 'Add to Cart' : 'Select a Size'">Select a Size</span>
                                @else
                                    Add to Cart
                                @endif
                            </button>
                        </form>
                    </div>
                @else
                    <button class="btn btn-secondary w-full mt-6 btn-lg opacity-50 cursor-not-allowed" disabled>
                        Out of Stock
                    </button>
                @endif

                {{-- Trust Chips --}}
                <div class="mt-6 grid grid-cols-2 gap-2 sm:grid-cols-4 border-t border-border pt-5">
                    @foreach ([
                        ['icon' => 'M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z', 'label' => 'Lab Tested'],
                        ['icon' => 'M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4', 'label' => 'Free Shipping'],
                        ['icon' => 'M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15', 'label' => '7-Day Return'],
                        ['icon' => 'M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z', 'label' => 'Secure Pay'],
                    ] as $chip)
                        <div class="flex flex-col items-center gap-1 rounded-lg bg-brand-bg p-2.5 text-center">
                            <svg class="h-5 w-5 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1.75">
                                <path stroke-linecap="round" stroke-linejoin="round" d="{{ $chip['icon'] }}"/>
                            </svg>
                            <span class="text-[11px] font-semibold text-brand-text">{{ $chip['label'] }}</span>
                        </div>
                    @endforeach
                </div>

            </div>
        </div>

        {{-- ── Product Description ── --}}
        <div class="mt-12 card p-6 sm:p-8">
            <h2 class="font-serif text-xl font-bold text-brand-text mb-4">Product Description</h2>
            <div class="prose prose-sm max-w-none text-brand-text/80 leading-relaxed">
                {!! nl2br(e($product->description)) !!}
            </div>
        </div>

        {{-- ── Related Products ── --}}
        @if ($related->total() > 0)
            <div class="mt-12">
                <h2 class="font-serif text-2xl font-bold text-brand-text mb-6">You Might Also Like</h2>
                <div class="grid grid-cols-2 gap-4 sm:gap-5 lg:grid-cols-4">
                    @foreach ($related->take(4) as $relProduct)
                        @if ($relProduct->id !== $product->id)
                            @include('components.product-card', ['product' => $relProduct])
                        @endif
                    @endforeach
                </div>
            </div>
        @endif

    </div>
</div>

@endsection
