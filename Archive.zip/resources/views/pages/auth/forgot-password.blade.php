@extends('layouts.app')
@section('title', 'Forgot Password')

@section('content')

<section class="min-h-[calc(100vh-4rem)] bg-brand-bg flex items-center justify-center py-12 px-4">
    <div class="w-full max-w-md">
        <div class="card p-8 sm:p-10">

            <div class="mb-8 text-center">
                <a href="{{ route('home') }}" class="inline-block mb-4">
                    <span class="font-serif text-2xl font-bold text-primary">FitNFresh</span>
                </a>
                <h1 class="font-serif text-2xl font-bold text-brand-text">Reset your password</h1>
                <p class="mt-1.5 text-sm text-brand-text/60">
                    Enter your email and we'll send a reset link.
                </p>
            </div>

            @if (session('status'))
                <div class="mb-6">
                    @include('components.alert', ['type' => 'success', 'message' => session('status')])
                </div>
            @endif

            <form method="POST" action="{{ route('password.email') }}">
                @csrf
                <div class="mb-5">
                    <label for="email" class="input-label">
                        Email Address <span class="text-red-500">*</span>
                    </label>
                    <input
                        type="email"
                        id="email"
                        name="email"
                        value="{{ old('email') }}"
                        autocomplete="email"
                        placeholder="you@example.com"
                        required
                        autofocus
                        class="input-field {{ $errors->has('email') ? 'border-red-400' : '' }}"
                    >
                    @error('email')
                        <p class="input-error">{{ $message }}</p>
                    @enderror
                </div>

                <button type="submit" class="btn btn-primary w-full btn-lg">
                    Send Reset Link
                </button>
            </form>

            <div class="mt-6 text-center">
                <a href="{{ route('login') }}" class="text-sm text-primary hover:text-primary-light transition-colors font-medium">
                    ← Back to Sign In
                </a>
            </div>
        </div>
    </div>
</section>

@endsection
