{{--
    Breadcrumb Component
    Usage:
    @include('components.breadcrumb', [
        'items' => [
            ['label' => 'Home', 'url' => route('home')],
            ['label' => 'Products', 'url' => route('products.index')],
            ['label' => 'Product Name'],  // last item — no URL
        ]
    ])
--}}
<nav aria-label="Breadcrumb" class="mb-6">
    <ol class="flex flex-wrap items-center gap-1.5 text-sm">
        @foreach ($items ?? [] as $index => $item)
            <li class="flex items-center gap-1.5">
                @if ($index > 0)
                    <svg class="h-3.5 w-3.5 text-brand-text/30" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7"/>
                    </svg>
                @endif

                @if (isset($item['url']))
                    <a href="{{ $item['url'] }}" class="text-brand-text/50 transition-colors hover:text-primary">
                        {{ $item['label'] }}
                    </a>
                @else
                    <span class="font-medium text-brand-text">{{ $item['label'] }}</span>
                @endif
            </li>
        @endforeach
    </ol>
</nav>
