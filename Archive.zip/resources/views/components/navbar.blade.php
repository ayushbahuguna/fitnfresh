<nav
    class="sticky top-0 z-50 bg-primary shadow-md"
    x-data="{ mobileOpen: false }"
>
    <div class="container-brand">
        <div class="flex h-16 items-center justify-between lg:h-18">

            {{-- Logo --}}
            <a href="{{ route('home') }}" class="flex items-center gap-2 shrink-0">
                <span class="font-serif text-2xl font-bold text-brand-inverse tracking-tight">FitNFresh</span>
            </a>

            {{-- Desktop Nav --}}
            <ul class="hidden items-center gap-8 lg:flex">
                <li>
                    <a href="{{ route('home') }}"
                       class="text-sm font-medium text-white/80 transition-colors hover:text-accent
                              {{ request()->routeIs('home') ? 'text-accent' : '' }}">
                        Home
                    </a>
                </li>
                <li>
                    <a href="{{ route('products.index') }}"
                       class="text-sm font-medium text-white/80 transition-colors hover:text-accent
                              {{ request()->routeIs('products.*') ? 'text-accent' : '' }}">
                        Shop
                    </a>
                </li>
                <li>
                    <a href="#about"
                       class="text-sm font-medium text-white/80 transition-colors hover:text-accent">
                        About
                    </a>
                </li>
                <li>
                    <a href="#contact"
                       class="text-sm font-medium text-white/80 transition-colors hover:text-accent">
                        Contact
                    </a>
                </li>
            </ul>

            {{-- Desktop Actions --}}
            <div class="hidden items-center gap-4 lg:flex">

                {{-- Cart Icon --}}
                <a href="{{ route('cart.index') }}"
                   class="relative flex items-center justify-center h-9 w-9 rounded-full text-white/80 transition-colors hover:bg-white/10 hover:text-white">
                    <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1.75">
                        <path stroke-linecap="round" stroke-linejoin="round"
                              d="M2.25 3h1.386c.51 0 .955.343 1.087.835l.383 1.437M7.5 14.25a3 3 0 00-3 3h15.75m-12.75-3h11.218c1.121-2.3 2.1-4.684 2.924-7.138a60.114 60.114 0 00-16.536-1.84M7.5 14.25L5.106 5.272M6 20.25a.75.75 0 11-1.5 0 .75.75 0 011.5 0zm12.75 0a.75.75 0 11-1.5 0 .75.75 0 011.5 0z"/>
                    </svg>
                    {{-- Cart count badge — populated in Phase 4 --}}
                    @if (isset($cartCount) && $cartCount > 0)
                        <span class="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-accent text-[10px] font-bold text-primary">
                            {{ $cartCount }}
                        </span>
                    @endif
                </a>

                @auth
                    {{-- Profile Dropdown --}}
                    <div class="relative" x-data="{ open: false }">
                        <button @click="open = !open"
                                class="flex items-center gap-2 rounded-full px-3 py-1.5 text-sm font-medium text-white/80 transition-colors hover:bg-white/10 hover:text-white">
                            <div class="h-7 w-7 rounded-full bg-accent flex items-center justify-center">
                                <span class="text-xs font-bold text-primary">
                                    {{ strtoupper(substr(auth()->user()->name, 0, 1)) }}
                                </span>
                            </div>
                            <span>{{ auth()->user()->name }}</span>
                            <svg class="h-4 w-4 transition-transform" :class="open ? 'rotate-180' : ''" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7"/>
                            </svg>
                        </button>

                        <div x-show="open"
                             x-cloak
                             @click.outside="open = false"
                             x-transition:enter="transition ease-out duration-100"
                             x-transition:enter-start="opacity-0 scale-95"
                             x-transition:enter-end="opacity-100 scale-100"
                             x-transition:leave="transition ease-in duration-75"
                             x-transition:leave-start="opacity-100 scale-100"
                             x-transition:leave-end="opacity-0 scale-95"
                             class="absolute right-0 mt-2 w-48 origin-top-right rounded-lg bg-surface py-1 shadow-lg ring-1 ring-border">
                            <a href="{{ route('profile.index') }}" class="block px-4 py-2 text-sm text-brand-text hover:bg-brand-bg">My Profile</a>
                            <a href="{{ route('orders.index') }}" class="block px-4 py-2 text-sm text-brand-text hover:bg-brand-bg">My Orders</a>

                            @if (auth()->user()->role === 'admin')
                                <div class="my-1 border-t border-border"></div>
                                <a href="{{ route('admin.dashboard') }}" class="block px-4 py-2 text-sm font-medium text-primary hover:bg-brand-bg">Admin Panel</a>
                            @endif

                            <div class="my-1 border-t border-border"></div>
                            <form method="POST" action="{{ route('logout') }}">
                                @csrf
                                <button type="submit" class="w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-brand-bg">
                                    Sign Out
                                </button>
                            </form>
                        </div>
                    </div>
                @else
                    <a href="{{ route('login') }}" class="btn btn-ghost btn-sm text-white/80 hover:text-white">
                        Sign In
                    </a>
                    <a href="{{ route('register') }}" class="btn btn-primary btn-sm">
                        Get Started
                    </a>
                @endauth
            </div>

            {{-- Mobile: Cart + Hamburger --}}
            <div class="flex items-center gap-3 lg:hidden">
                <a href="{{ route('cart.index') }}"
                   class="relative flex h-9 w-9 items-center justify-center rounded-full text-white/80 transition-colors hover:bg-white/10">
                    <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1.75">
                        <path stroke-linecap="round" stroke-linejoin="round"
                              d="M2.25 3h1.386c.51 0 .955.343 1.087.835l.383 1.437M7.5 14.25a3 3 0 00-3 3h15.75m-12.75-3h11.218c1.121-2.3 2.1-4.684 2.924-7.138a60.114 60.114 0 00-16.536-1.84M7.5 14.25L5.106 5.272M6 20.25a.75.75 0 11-1.5 0 .75.75 0 011.5 0zm12.75 0a.75.75 0 11-1.5 0 .75.75 0 011.5 0z"/>
                    </svg>
                    @if (isset($cartCount) && $cartCount > 0)
                        <span class="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-accent text-[10px] font-bold text-primary">
                            {{ $cartCount }}
                        </span>
                    @endif
                </a>

                <button @click="mobileOpen = !mobileOpen"
                        class="flex h-9 w-9 items-center justify-center rounded-md text-white/80 transition-colors hover:bg-white/10"
                        aria-label="Toggle menu">
                    <svg x-show="!mobileOpen" class="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M4 6h16M4 12h16M4 18h16"/>
                    </svg>
                    <svg x-show="mobileOpen" x-cloak class="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/>
                    </svg>
                </button>
            </div>

        </div>
    </div>

    {{-- Mobile Menu --}}
    <div
        x-show="mobileOpen"
        x-cloak
        x-transition:enter="transition ease-out duration-200"
        x-transition:enter-start="opacity-0 -translate-y-2"
        x-transition:enter-end="opacity-100 translate-y-0"
        x-transition:leave="transition ease-in duration-150"
        x-transition:leave-start="opacity-100 translate-y-0"
        x-transition:leave-end="opacity-0 -translate-y-2"
        class="border-t border-white/10 bg-primary-light lg:hidden"
    >
        <div class="container-brand py-4">
            <ul class="space-y-1">
                <li>
                    <a href="{{ route('home') }}"
                       @click="mobileOpen = false"
                       class="block rounded-lg px-3 py-2.5 text-sm font-medium text-white/80 transition-colors hover:bg-white/10 hover:text-white
                              {{ request()->routeIs('home') ? 'bg-white/10 text-white' : '' }}">
                        Home
                    </a>
                </li>
                <li>
                    <a href="{{ route('products.index') }}"
                       @click="mobileOpen = false"
                       class="block rounded-lg px-3 py-2.5 text-sm font-medium text-white/80 transition-colors hover:bg-white/10 hover:text-white
                              {{ request()->routeIs('products.*') ? 'bg-white/10 text-white' : '' }}">
                        Shop
                    </a>
                </li>
                <li>
                    <a href="#about" @click="mobileOpen = false"
                       class="block rounded-lg px-3 py-2.5 text-sm font-medium text-white/80 transition-colors hover:bg-white/10 hover:text-white">
                        About
                    </a>
                </li>
                <li>
                    <a href="#contact" @click="mobileOpen = false"
                       class="block rounded-lg px-3 py-2.5 text-sm font-medium text-white/80 transition-colors hover:bg-white/10 hover:text-white">
                        Contact
                    </a>
                </li>
            </ul>

            <div class="mt-4 border-t border-white/10 pt-4">
                @auth
                    <div class="mb-3 flex items-center gap-3 px-3">
                        <div class="h-8 w-8 rounded-full bg-accent flex items-center justify-center shrink-0">
                            <span class="text-xs font-bold text-primary">
                                {{ strtoupper(substr(auth()->user()->name, 0, 1)) }}
                            </span>
                        </div>
                        <span class="text-sm font-medium text-white">{{ auth()->user()->name }}</span>
                    </div>
                    <a href="{{ route('profile.index') }}" class="block rounded-lg px-3 py-2 text-sm text-white/80 hover:bg-white/10 hover:text-white">My Profile</a>
                    <a href="{{ route('orders.index') }}" class="block rounded-lg px-3 py-2 text-sm text-white/80 hover:bg-white/10 hover:text-white">My Orders</a>
                    @if (auth()->user()->role === 'admin')
                        <a href="{{ route('admin.dashboard') }}" class="block rounded-lg px-3 py-2 text-sm font-medium text-accent hover:bg-white/10">Admin Panel</a>
                    @endif
                    <form method="POST" action="{{ route('logout') }}" class="mt-2">
                        @csrf
                        <button type="submit" class="w-full text-left rounded-lg px-3 py-2 text-sm text-red-400 hover:bg-white/10">
                            Sign Out
                        </button>
                    </form>
                @else
                    <div class="flex flex-col gap-2">
                        <a href="{{ route('login') }}" class="btn btn-outline-accent w-full">
                            Sign In
                        </a>
                        <a href="{{ route('register') }}" class="btn btn-primary w-full">
                            Get Started
                        </a>
                    </div>
                @endauth
            </div>
        </div>
    </div>

</nav>
