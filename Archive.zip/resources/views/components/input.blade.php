{{--
    Input Field Component
    Usage:
    @include('components.input', [
        'name'        => 'email',
        'label'       => 'Email Address',
        'type'        => 'email',          // default: text
        'placeholder' => 'you@example.com',
        'value'       => old('email'),
        'required'    => true,
        'autocomplete'=> 'email',
    ])
--}}
@php
    $inputType   = $type ?? 'text';
    $inputName   = $name ?? '';
    $inputId     = $id ?? $inputName;
    $inputValue  = $value ?? old($inputName, '');
    $isRequired  = $required ?? false;
@endphp

<div class="w-full">
    @if (isset($label) && $label)
        <label for="{{ $inputId }}" class="input-label">
            {{ $label }}
            @if ($isRequired)
                <span class="text-red-500 ml-0.5" aria-hidden="true">*</span>
            @endif
        </label>
    @endif

    <input
        type="{{ $inputType }}"
        name="{{ $inputName }}"
        id="{{ $inputId }}"
        value="{{ $inputValue }}"
        placeholder="{{ $placeholder ?? '' }}"
        autocomplete="{{ $autocomplete ?? 'off' }}"
        {{ $isRequired ? 'required' : '' }}
        {{ isset($disabled) && $disabled ? 'disabled' : '' }}
        {{ isset($readonly) && $readonly ? 'readonly' : '' }}
        class="input-field {{ $class ?? '' }} {{ $errors->has($inputName) ? 'border-red-400 focus:border-red-500' : '' }}"
        {{ $attributes ?? '' }}
    >

    @error($inputName)
        <p class="input-error">{{ $message }}</p>
    @enderror
</div>
