{{-- Product Card Component --}}
<div class="card group flex flex-col">

    {{-- Image --}}
    <a href="{{ route('products.show', $product->slug) }}" class="relative block overflow-hidden bg-brand-bg aspect-square">
        @if ($product->primaryImage)
            <img
                src="{{ $product->primary_image_url }}"
                alt="{{ $product->name }}"
                class="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                loading="lazy"
            >
        @else
            <div class="flex h-full w-full items-center justify-center">
                <svg class="h-16 w-16 text-border" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/>
                </svg>
            </div>
        @endif

        {{-- Badges --}}
        <div class="absolute left-2.5 top-2.5 flex flex-col gap-1.5">
            @if ($product->is_featured)
                <span class="badge badge-accent text-[10px]">Bestseller</span>
            @endif
            @if ($product->hasDiscount())
                <span class="badge badge-primary text-[10px]">{{ $product->discountPercent() }}% OFF</span>
            @endif
        </div>

        {{-- Out of stock overlay --}}
        @unless ($product->isInStock())
            <div class="absolute inset-0 bg-brand-text/40 flex items-center justify-center">
                <span class="bg-surface text-brand-text text-xs font-bold px-3 py-1.5 rounded-full">Out of Stock</span>
            </div>
        @endunless
    </a>

    {{-- Info --}}
    <div class="flex flex-1 flex-col p-3.5 sm:p-4">
        <a href="{{ route('products.show', $product->slug) }}" class="flex-1">
            <h3 class="font-serif text-sm font-semibold text-brand-text line-clamp-2 hover:text-primary transition-colors sm:text-base">
                {{ $product->name }}
            </h3>
            @if ($product->short_description)
                <p class="mt-1 text-xs text-brand-text/55 line-clamp-2 leading-relaxed">
                    {{ $product->short_description }}
                </p>
            @endif
        </a>

        <div class="mt-3">
            {{-- Price --}}
            <div class="flex items-baseline gap-1.5 flex-wrap">
                <span class="text-base font-bold text-primary sm:text-lg">
                    ₹{{ number_format($product->price) }}
                </span>
                @if ($product->hasDiscount())
                    <span class="text-xs text-brand-text/40 line-through">
                        ₹{{ number_format($product->compare_price) }}
                    </span>
                @endif
            </div>

            {{-- Low stock warning --}}
            @if ($product->isLowStock())
                <p class="mt-0.5 text-xs font-medium text-amber-600">Only {{ $product->stock }} left!</p>
            @endif

            {{-- Add to Cart — wired in Phase 4 --}}
            <button
                class="btn btn-secondary w-full mt-3 btn-sm"
                {{ ! $product->isInStock() ? 'disabled' : '' }}
                data-product-id="{{ $product->id }}"
                data-action="add-to-cart"
            >
                @if ($product->isInStock())
                    <svg class="h-3.5 w-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M12 4v16m8-8H4"/>
                    </svg>
                    Add to Cart
                @else
                    Out of Stock
                @endif
            </button>
        </div>
    </div>
</div>
