{{--
    Button Component
    Usage:
    @include('components.button', [
        'label'    => 'Add to Cart',
        'variant'  => 'primary',   // primary | secondary | outline | ghost
        'size'     => 'md',        // sm | md | lg
        'type'     => 'button',    // button | submit
        'href'     => null,        // renders <a> if set
        'disabled' => false,
        'class'    => '',
    ])
--}}
@php
    $variant  = $variant ?? 'primary';
    $size     = $size ?? 'md';
    $type     = $type ?? 'button';
    $href     = $href ?? null;
    $disabled = $disabled ?? false;

    $variantClass = match($variant) {
        'secondary'     => 'btn-secondary',
        'outline'       => 'btn-outline',
        'outline-accent'=> 'btn-outline-accent',
        'ghost'         => 'btn-ghost',
        default         => 'btn-primary',
    };

    $sizeClass = match($size) {
        'sm' => 'btn-sm',
        'lg' => 'btn-lg',
        default => '',
    };

    $classes = implode(' ', array_filter(['btn', $variantClass, $sizeClass, $class ?? '']));
@endphp

@if ($href)
    <a href="{{ $href }}"
       class="{{ $classes }}"
       {{ $disabled ? 'aria-disabled=true tabindex=-1' : '' }}>
        {{ $label ?? '' }}
        {{ $slot ?? '' }}
    </a>
@else
    <button
        type="{{ $type }}"
        class="{{ $classes }}"
        {{ $disabled ? 'disabled' : '' }}>
        {{ $label ?? '' }}
        {{ $slot ?? '' }}
    </button>
@endif
