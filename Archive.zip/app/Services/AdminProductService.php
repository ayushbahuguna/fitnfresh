<?php

namespace App\Services;

use App\Models\Product;
use App\Models\ProductImage;
use App\Models\ProductVariant;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

class AdminProductService
{
    public function __construct(private readonly ProductService $productService) {}

    /**
     * All products for admin — paginated, no active filter.
     */
    public function getAllProducts(string $search = ''): LengthAwarePaginator
    {
        $query = Product::query()
            ->with(['category', 'primaryImage'])
            ->select([
                'id', 'category_id', 'name', 'slug', 'sku',
                'price', 'stock', 'is_active', 'is_featured', 'created_at',
            ]);

        if ($search) {
            $like = '%' . $search . '%';
            $query->where(fn ($q) => $q
                ->where('name', 'like', $like)
                ->orWhere('sku', 'like', $like)
            );
        }

        return $query->orderByDesc('created_at')->paginate(20)->withQueryString();
    }

    /**
     * Create product with images and variants in a single transaction.
     */
    public function createProduct(array $data, array $images = [], array $variants = []): Product
    {
        return DB::transaction(function () use ($data, $images, $variants) {
            $data['slug'] = $this->productService->generateSlug($data['name']);

            $product = Product::create($data);

            $this->syncImages($product, $images);
            $this->syncVariants($product, $variants);

            return $product;
        });
    }

    /**
     * Update product with images and variants in a single transaction.
     */
    public function updateProduct(Product $product, array $data, array $images = [], array $variants = []): Product
    {
        return DB::transaction(function () use ($product, $data, $images, $variants) {
            if (isset($data['name']) && $data['name'] !== $product->name) {
                $data['slug'] = $this->productService->generateSlug($data['name'], $product->id);
            }

            $product->update($data);

            if (! empty($images)) {
                $this->syncImages($product, $images);
            }

            if (! empty($variants)) {
                $this->syncVariants($product, $variants);
            }

            return $product->fresh();
        });
    }

    /**
     * Soft-delete by toggling is_active (safe), or hard-delete if explicitly chosen.
     */
    public function deleteProduct(Product $product): void
    {
        DB::transaction(function () use ($product) {
            // Delete stored images from disk
            foreach ($product->images as $image) {
                Storage::disk('public')->delete($image->image_path);
            }

            $product->delete();
        });
    }

    // ── Private Helpers ───────────────────────────────────────────────────────

    private function syncImages(Product $product, array $uploadedFiles): void
    {
        $isFirst = $product->images()->count() === 0;

        foreach ($uploadedFiles as $index => $file) {
            if (! ($file instanceof UploadedFile)) {
                continue;
            }

            $path = $file->store('products', 'public');

            $product->images()->create([
                'image_path' => $path,
                'sort_order' => $index,
                'is_primary' => $isFirst && $index === 0,
            ]);

            $isFirst = false;
        }
    }

    private function syncVariants(Product $product, array $variantsData): void
    {
        // Delete removed variants (those not in the incoming payload)
        $incomingIds = collect($variantsData)->pluck('id')->filter()->all();
        $product->variants()->whereNotIn('id', $incomingIds)->delete();

        foreach ($variantsData as $index => $variantData) {
            if (isset($variantData['id'])) {
                ProductVariant::where('id', $variantData['id'])
                    ->where('product_id', $product->id)
                    ->update([
                        'name'       => $variantData['name'],
                        'sku'        => $variantData['sku'],
                        'price'      => $variantData['price'],
                        'stock'      => $variantData['stock'] ?? 0,
                        'sort_order' => $index,
                    ]);
            } else {
                $product->variants()->create([
                    'name'       => $variantData['name'],
                    'sku'        => $variantData['sku'],
                    'price'      => $variantData['price'],
                    'stock'      => $variantData['stock'] ?? 0,
                    'sort_order' => $index,
                ]);
            }
        }
    }
}
