<?php

namespace App\Services;

use App\Models\User;
use Illuminate\Auth\Events\Registered;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\ValidationException;

class AuthService
{
    /**
     * Register a new user and log them in.
     */
    public function register(array $data): User
    {
        $user = User::create([
            'name'     => $data['name'],
            'email'    => $data['email'],
            'password' => Hash::make($data['password']),
            'phone'    => $data['phone'] ?? null,
            'role'     => 'user',
            'is_active'=> true,
        ]);

        event(new Registered($user));

        Auth::login($user);

        return $user;
    }

    /**
     * Attempt to authenticate a user.
     *
     * @throws ValidationException
     */
    public function login(array $credentials, bool $remember = false): User
    {
        if (! Auth::attempt([
            'email'    => $credentials['email'],
            'password' => $credentials['password'],
        ], $remember)) {
            throw ValidationException::withMessages([
                'email' => 'These credentials do not match our records.',
            ]);
        }

        /** @var User $user */
        $user = Auth::user();

        if (! $user->is_active) {
            Auth::logout();
            throw ValidationException::withMessages([
                'email' => 'Your account has been deactivated. Please contact support.',
            ]);
        }

        request()->session()->regenerate();

        return $user;
    }

    /**
     * Log the current user out.
     */
    public function logout(): void
    {
        Auth::logout();
        request()->session()->invalidate();
        request()->session()->regenerateToken();
    }

    /**
     * Determine the post-login redirect URL based on role.
     */
    public function redirectAfterLogin(User $user): string
    {
        if ($user->isAdmin()) {
            return route('admin.dashboard');
        }

        return session()->pull('url.intended', route('home'));
    }
}
