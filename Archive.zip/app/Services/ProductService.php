<?php

namespace App\Services;

use App\Models\Product;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Database\Eloquent\Collection;

class ProductService
{
    /**
     * Paginated product listing with eager loading (N+1 safe).
     */
    public function getActiveProducts(array $filters = []): LengthAwarePaginator
    {
        $query = Product::query()
            ->active()
            ->with(['primaryImage', 'category'])
            ->select([
                'id', 'category_id', 'name', 'slug', 'short_description',
                'price', 'compare_price', 'stock', 'is_featured',
            ]);

        if (! empty($filters['featured'])) {
            $query->featured();
        }

        if (! empty($filters['category'])) {
            $query->whereHas('category', fn ($q) => $q->where('slug', $filters['category']));
        }

        if (! empty($filters['search'])) {
            $search = '%' . $filters['search'] . '%';
            $query->where(fn ($q) => $q
                ->where('name', 'like', $search)
                ->orWhere('short_description', 'like', $search)
            );
        }

        $sort = $filters['sort'] ?? 'newest';

        match ($sort) {
            'price_asc'  => $query->orderBy('price', 'asc'),
            'price_desc' => $query->orderBy('price', 'desc'),
            'featured'   => $query->orderByDesc('is_featured')->orderByDesc('created_at'),
            default      => $query->orderByDesc('created_at'),
        };

        return $query->paginate(12)->withQueryString();
    }

    /**
     * Fetch featured products for the homepage — no pagination.
     */
    public function getFeaturedProducts(int $limit = 4): Collection
    {
        return Product::query()
            ->active()
            ->featured()
            ->with(['primaryImage'])
            ->select([
                'id', 'name', 'slug', 'short_description',
                'price', 'compare_price', 'stock', 'is_featured',
            ])
            ->orderByDesc('created_at')
            ->limit($limit)
            ->get();
    }

    /**
     * Find a product by slug with all needed relations — no N+1.
     */
    public function findBySlug(string $slug): Product
    {
        return Product::query()
            ->active()
            ->where('slug', $slug)
            ->with(['images', 'variants', 'category'])
            ->select([
                'id', 'category_id', 'name', 'slug', 'sku', 'description',
                'short_description', 'price', 'compare_price', 'stock',
                'is_featured', 'meta_title', 'meta_description',
            ])
            ->firstOrFail();
    }

    /**
     * Generate a unique slug from the product name.
     */
    public function generateSlug(string $name, ?int $excludeId = null): string
    {
        $base = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $name), '-'));
        $slug = $base;
        $count = 1;

        while (true) {
            $query = Product::where('slug', $slug);

            if ($excludeId) {
                $query->where('id', '!=', $excludeId);
            }

            if (! $query->exists()) {
                break;
            }

            $slug = $base . '-' . $count++;
        }

        return $slug;
    }
}
