<?php

namespace App\Http\Requests\Product;

use Illuminate\Foundation\Http\FormRequest;

class StoreProductRequest extends FormRequest
{
    public function authorize(): bool
    {
        return auth()->check() && auth()->user()->isAdmin();
    }

    public function rules(): array
    {
        return [
            'name'              => ['required', 'string', 'max:255'],
            'category_id'       => ['required', 'integer', 'exists:categories,id'],
            'sku'               => ['required', 'string', 'max:100', 'unique:products,sku'],
            'description'       => ['required', 'string', 'min:20'],
            'short_description' => ['nullable', 'string', 'max:500'],
            'price'             => ['required', 'numeric', 'min:0'],
            'compare_price'     => ['nullable', 'numeric', 'min:0', 'gt:price'],
            'stock'             => ['required', 'integer', 'min:0'],
            'is_active'         => ['boolean'],
            'is_featured'       => ['boolean'],
            'meta_title'        => ['nullable', 'string', 'max:255'],
            'meta_description'  => ['nullable', 'string', 'max:500'],
            'images'            => ['nullable', 'array', 'max:6'],
            'images.*'          => ['image', 'mimes:jpeg,png,webp', 'max:2048'],
            'variants'          => ['nullable', 'array'],
            'variants.*.name'   => ['required_with:variants', 'string', 'max:100'],
            'variants.*.sku'    => ['required_with:variants', 'string', 'max:100', 'distinct', 'unique:product_variants,sku'],
            'variants.*.price'  => ['required_with:variants', 'numeric', 'min:0'],
            'variants.*.stock'  => ['required_with:variants', 'integer', 'min:0'],
        ];
    }
}
