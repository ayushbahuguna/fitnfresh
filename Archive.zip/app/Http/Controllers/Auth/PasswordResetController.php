<?php
namespace App\Http\Controllers\Auth;
use App\Http\Controllers\Controller;
class PasswordResetController extends Controller
{
    public function showForm() { return view('pages.auth.forgot-password'); }
    public function send() { return back(); }
    public function reset() { return back(); }
}
