<?php
namespace App\Http\Controllers\Web;
use App\Http\Controllers\Controller;
class CartController extends Controller
{
    public function index() { return view('pages.cart.index'); }
    public function add() { return back(); }
    public function update(int $id) { return back(); }
    public function remove(int $id) { return back(); }
    public function applyCoupon() { return back(); }
}
