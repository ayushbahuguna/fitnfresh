<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Services\ProductService;
use Illuminate\Http\Request;
use Illuminate\View\View;

class ProductController extends Controller
{
    public function __construct(private readonly ProductService $productService) {}

    public function index(Request $request): View
    {
        $filters = $request->only(['search', 'category', 'sort', 'featured']);

        $products = $this->productService->getActiveProducts($filters);

        return view('pages.products.index', compact('products', 'filters'));
    }

    public function show(string $slug): View
    {
        $product = $this->productService->findBySlug($slug);

        $related = $this->productService->getActiveProducts([
            'category' => $product->category?->slug,
        ]);

        return view('pages.products.show', compact('product', 'related'));
    }
}
