<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Services\ProductService;
use Illuminate\View\View;

class HomeController extends Controller
{
    public function __construct(private readonly ProductService $productService) {}

    public function index(): View
    {
        $featuredProducts = $this->productService->getFeaturedProducts(4);

        return view('pages.home.index', compact('featuredProducts'));
    }
}
