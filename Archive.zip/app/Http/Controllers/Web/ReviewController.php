<?php
namespace App\Http\Controllers\Web;
use App\Http\Controllers\Controller;
class ReviewController extends Controller
{
    public function store() { return back(); }
}
