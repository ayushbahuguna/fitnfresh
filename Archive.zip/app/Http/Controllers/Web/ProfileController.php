<?php
namespace App\Http\Controllers\Web;
use App\Http\Controllers\Controller;
class ProfileController extends Controller
{
    public function index() { return view('pages.profile.index'); }
    public function update() { return back(); }
    public function storeAddress() { return back(); }
    public function destroyAddress(int $id) { return back(); }
}
