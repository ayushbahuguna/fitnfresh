<?php
namespace App\Http\Controllers\Web;
use App\Http\Controllers\Controller;
class OrderController extends Controller
{
    public function index() { return view('pages.orders.index'); }
    public function show(string $orderNumber) { abort(404); }
}
