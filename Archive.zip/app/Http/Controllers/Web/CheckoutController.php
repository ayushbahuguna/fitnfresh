<?php
namespace App\Http\Controllers\Web;
use App\Http\Controllers\Controller;
class CheckoutController extends Controller
{
    public function index() { return view('pages.checkout.index'); }
    public function store() { return back(); }
}
