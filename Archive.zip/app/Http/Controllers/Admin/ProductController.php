<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Product\StoreProductRequest;
use App\Http\Requests\Product\UpdateProductRequest;
use App\Models\Category;
use App\Models\Product;
use App\Services\AdminProductService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class ProductController extends Controller
{
    public function __construct(private readonly AdminProductService $adminProductService) {}

    public function index(Request $request): View
    {
        $products = $this->adminProductService->getAllProducts(
            $request->string('search')->toString()
        );

        return view('pages.admin.products.index', compact('products'));
    }

    public function create(): View
    {
        $categories = Category::where('is_active', true)
            ->select('id', 'name')
            ->orderBy('name')
            ->get();

        return view('pages.admin.products.create', compact('categories'));
    }

    public function store(StoreProductRequest $request): RedirectResponse
    {
        $data     = $request->safe()->except(['images', 'variants']);
        $images   = $request->file('images', []);
        $variants = $request->input('variants', []);

        $data['is_active']   = $request->boolean('is_active');
        $data['is_featured'] = $request->boolean('is_featured');

        $product = $this->adminProductService->createProduct($data, $images, $variants);

        return redirect()->route('admin.products.index')
            ->with('success', "Product \"{$product->name}\" created successfully.");
    }

    public function edit(int $id): View
    {
        $product = Product::with(['images', 'variants', 'category'])
            ->findOrFail($id);

        $categories = Category::where('is_active', true)
            ->select('id', 'name')
            ->orderBy('name')
            ->get();

        return view('pages.admin.products.edit', compact('product', 'categories'));
    }

    public function update(UpdateProductRequest $request, int $id): RedirectResponse
    {
        $product  = Product::findOrFail($id);
        $data     = $request->safe()->except(['images', 'variants']);
        $images   = $request->file('images', []);
        $variants = $request->input('variants', []);

        $data['is_active']   = $request->boolean('is_active');
        $data['is_featured'] = $request->boolean('is_featured');

        $this->adminProductService->updateProduct($product, $data, $images, $variants);

        return redirect()->route('admin.products.index')
            ->with('success', "Product \"{$product->name}\" updated successfully.");
    }

    public function destroy(int $id): RedirectResponse
    {
        $product = Product::with('images')->findOrFail($id);
        $name    = $product->name;

        $this->adminProductService->deleteProduct($product);

        return redirect()->route('admin.products.index')
            ->with('success', "Product \"{$name}\" deleted.");
    }
}
