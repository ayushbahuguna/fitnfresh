<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
class ReviewController extends Controller
{
    public function index() { return view('pages.admin.reviews.index'); }
    public function approve(int $id) { return back(); }
    public function destroy(int $id) { return back(); }
}
