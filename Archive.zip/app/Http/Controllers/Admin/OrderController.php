<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
class OrderController extends Controller
{
    public function index() { return view('pages.admin.orders.index'); }
    public function show(int $id) { abort(404); }
    public function updateStatus(int $id) { return back(); }
}
